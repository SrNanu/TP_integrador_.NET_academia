﻿namespace AcademiaWeb.Servicios
{
    public class UsuarioContainer
    {
        public Usuario UsuarioContenido { get; set; }
    }

    public class CursoContainer
    {
        public Curso CursoContenido { get; set; }
    }
}


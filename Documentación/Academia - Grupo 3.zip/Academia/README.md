# TP_integrador_.NET_academia

Este trabajo práctico consta de la realización de una aplicación web utilizando el entorno .NET. En nuestro caso, realizaremos un sistema de gestión de inscripción de alumnos al cursado de materias de un año lectivo.

## Materia

**Tecnologías de desarrollo de software IDE**

## Comisión

**302**

## Grupo 3

### Integrantes

- **Cosentino, Lucio** - 50785
- **Cataldi, Santino** - 50384
- **Mondino, Juan Cruz** - 51922

